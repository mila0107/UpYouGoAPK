package com.example.upyougo;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseAccess {
    private SQLiteOpenHelper openHelper;
    private SQLiteDatabase db;
    private static DatabaseAccess instance;

    public DatabaseAccess(Context context){
        this.openHelper = new DatabaseHelper(context);
    }

    public static DatabaseAccess getInstance(Context context){
        if(instance == null){
            instance = new DatabaseAccess(context);
        }
        return instance;
    }

    public void open(){
        db = openHelper.getWritableDatabase();
    }

    public void close(){
        if (db != null){
            db.close();
        }
    }

    public Boolean checklogin(String email) {
        SQLiteDatabase MyDB = this.openHelper.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("SELECT * FROM alunos WHERE email = ?", new String[]{email});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }

    public Boolean checkloginpass(String email, String senha) {
        SQLiteDatabase MyDB = this.openHelper.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("SELECT * FROM alunos WHERE email = ? and senha = ?", new String[]{email,senha});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }

    public String checkpass(String senha) {
        String query = "SELECT senha FROM alunos WHERE nome = ?";
        try (Cursor cursor = db.rawQuery(query, new String[]{senha})) {
            return cursor.moveToFirst() ? cursor.getString(cursor.getColumnIndexOrThrow("senha")) : null;
        }
    }
}
