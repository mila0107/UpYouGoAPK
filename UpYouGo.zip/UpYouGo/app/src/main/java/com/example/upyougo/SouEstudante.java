package com.example.upyougo;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class SouEstudante extends AppCompatActivity {

    private EditText login, pass;
    public Button btnLogin;

    DatabaseAccess db;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        getWindow().requestFeature(Window.FEATURE_CONTENT_TRANSITIONS);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sou_estudante);

        // Para validar o Login
        login = findViewById(R.id.loginEmail);
        pass = findViewById(R.id.loginPassword);
        btnLogin = findViewById(R.id.btnLogin);
        db = new DatabaseAccess(this);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = login.getText().toString();
                String senha = pass.getText().toString();

                if (login.equals("") || pass.equals(""))
                    Toast.makeText(SouEstudante.this, "Login ou senha incorretos!", Toast.LENGTH_SHORT).show();
                else {
                    Boolean checkpass = db.checkloginpass(email, senha);
                    if (checkpass==true){
                        Toast.makeText(SouEstudante.this, "Bem Vindo de Volta!", Toast.LENGTH_SHORT).show();
                        //Intent para chamar outra página
                        Intent intent = new Intent(SouEstudante.this, VagasEstudante.class);
                        startActivity(intent);
                    }else{
                        Toast.makeText(SouEstudante.this, "Credenciais Inválidas!", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });

        // Função que vai para o Esqueci a Senha
        TextView ForgotPassword = findViewById(R.id.ForgotPassword);
        ForgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showForgotPasswordAlert();
            }
        });

        // Função que vai para o Formulário de Cadastro
        TextView textViewRegister = findViewById(R.id.Registo);
        textViewRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SouEstudante.this, CadastroEstudante.class);
                startActivity(intent);
            }
        });

    }
    private void showForgotPasswordAlert() {
        // Exibir Alerta do Esqueci a Senha
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Esqueci a Senha");
        builder.setMessage("Um email de verificação foi enviado para o seu email");
        builder.show();
    }
}

