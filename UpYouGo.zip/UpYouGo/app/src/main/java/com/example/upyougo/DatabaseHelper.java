package com.example.upyougo;

import com.readystatesoftware.sqliteasset.SQLiteAssetHelper;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class DatabaseHelper extends SQLiteAssetHelper {
    private static final String DATABASE_NAME = "UsersDB.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_NAME = "alunos";
    public static final String COLUMN_NOME = "nome";
    public static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_SENHA = "senha";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    //Método para adicionar um estudante ao banco de dados
    public long addEstudante(String nome, String email, String senha) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NOME, nome);
        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_SENHA, senha);
        long id = db.insert(TABLE_NAME, null, values);
        db.close();
        return id;
    }
}


