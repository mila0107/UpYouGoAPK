package com.example.upyougo;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;


public class VagasEstudante extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vagas_estudante);

        // Configurar o clique do botão
        Button buttonCandidatarNoesis = findViewById(R.id.buttonCandidatarNoesis);
        configurarBotaoCandidatar(buttonCandidatarNoesis);

        Button buttonCandidatarSysnovare = findViewById(R.id.buttonCandidatarSysnovare);
        configurarBotaoCandidatar(buttonCandidatarSysnovare);

        Button buttonCandidatarTeleperformance = findViewById(R.id.buttonCandidatarTeleperformance);
        configurarBotaoCandidatar(buttonCandidatarTeleperformance);

        Button buttonCandidatarGoogle = findViewById(R.id.buttonCandidatarGoogle);
        configurarBotaoCandidatar(buttonCandidatarGoogle);
    }

    private void configurarBotaoCandidatar(Button buttonCandidatar) {
        buttonCandidatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showCandidatarAlert();
            }
        });
    }

    private void showCandidatarAlert() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Candidatura");
        builder.setMessage("Um email com instruções de candidatura foi enviado para o seu email");
        builder.show();
    }
}