package com.example.upyougo;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class PasswordHasher {
    // Método para criar um hash da senha
    public static String hashPassword(String senha) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = md.digest(senha.getBytes());

            // Converta os bytes hash para uma representação hexadecimal
            StringBuilder stringBuilder = new StringBuilder();
            for (byte b : hashedBytes) {
                stringBuilder.append(String.format("%02x", b));
            }

            return stringBuilder.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Método para verificar se a senha fornecida corresponde ao hash armazenado
    public static boolean checkPassword(String senha, String storedHash) {
        String inputHash = hashPassword(senha);
        return inputHash != null && inputHash.equals(storedHash);
    }
}
