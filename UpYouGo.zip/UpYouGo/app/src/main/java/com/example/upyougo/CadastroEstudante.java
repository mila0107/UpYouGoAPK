package com.example.upyougo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CadastroEstudante extends AppCompatActivity {

    private EditText nomeEditText, emailEditText, senhaEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_estudante);

        nomeEditText = findViewById(R.id.cadNome);
        emailEditText = findViewById(R.id.cadEmail);
        senhaEditText = findViewById(R.id.cadPassword);

        Button cadastrarButton = findViewById(R.id.btnCadastrar);

        cadastrarButton.setOnClickListener(view -> cadastrarEstudante());
    }

    private void cadastrarEstudante() {
        String nome = nomeEditText.getText().toString();
        String email = emailEditText.getText().toString();
        String senha = senhaEditText.getText().toString();

        if (nome.isEmpty() || email.isEmpty() || senha.isEmpty()) {
            Toast.makeText(CadastroEstudante.this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
            return;
        }

        //Adicionar estudante usando o método addEstudante na classe DatabaseHelper
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        try {
            long id = dbHelper.addEstudante(nome, email, senha);

            if (id != -1) {
                Toast.makeText(this, "Estudante cadastrado com sucesso!", Toast.LENGTH_SHORT).show();

                // Após cadastrar com sucesso, intent para nova pagina
                Intent intent = new Intent(CadastroEstudante.this, VagasEstudante.class);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Erro ao cadastrar estudante.", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Erro ao interagir com o banco de dados.", Toast.LENGTH_SHORT).show();
        }

    }
}