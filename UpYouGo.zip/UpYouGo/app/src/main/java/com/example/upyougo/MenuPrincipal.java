package com.example.upyougo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.ActivityOptionsCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;

public class MenuPrincipal extends AppCompatActivity {

    @Override
        protected void onCreate(Bundle savedInstanceState) {
            getWindow().requestFeature(Window.FEATURE_CONTENT_TRANSITIONS);
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_menu_principal);
        }

        public void ButtonEstudante(View View) {
            Intent intent = new Intent(this, SouEstudante.class);
            Button button = (Button) findViewById(R.id.button);
            ActivityOptionsCompat compat = ActivityOptionsCompat.makeSceneTransitionAnimation(this, button, "transition_key");
            ActivityCompat.startActivity(this,intent, compat.toBundle() );
        }

        public void ButtonEmpresa(View View) {
        Intent intent = new Intent(this, SouEmpresa.class);
        Button button = (Button) findViewById(R.id.btnEmpresa);
        ActivityOptionsCompat compat = ActivityOptionsCompat.makeSceneTransitionAnimation(this, button, "transition_key");
        ActivityCompat.startActivity(this,intent, compat.toBundle() );
        }
        public void ButtonInstituicao(View View) {
        Intent intent = new Intent(this, SouInstituicao.class);
        Button button = (Button) findViewById(R.id.btnInstituicao);
        ActivityOptionsCompat compat = ActivityOptionsCompat.makeSceneTransitionAnimation(this, button, "transition_key");
        ActivityCompat.startActivity(this,intent, compat.toBundle() );
        }
}